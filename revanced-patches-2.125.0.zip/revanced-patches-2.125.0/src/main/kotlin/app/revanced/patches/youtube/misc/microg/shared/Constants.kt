package app.revanced.patches.youtube.misc.microg.shared

object Constants {
    internal const val REVANCED_APP_NAME = "YouTube ReVanced"
    internal const val REVANCED_PACKAGE_NAME = "app.revanced.android.youtube"
    internal const val PACKAGE_NAME = "com.google.android.youtube"
    internal const val SPOOFED_PACKAGE_NAME = PACKAGE_NAME
    internal const val SPOOFED_PACKAGE_SIGNATURE = "24bb24c05e47e0aefa68a58a766179d9b613a600"
}