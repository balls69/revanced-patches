package app.revanced.patches.shared.settings.impl

enum class InputType(val type: String) {
    STRING("text"),
    NUMBER("number"),
}